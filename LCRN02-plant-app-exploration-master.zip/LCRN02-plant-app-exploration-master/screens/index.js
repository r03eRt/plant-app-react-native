import Home from "./Home";
import PlantDetail from "./PlantDetail";

export {
    Home,
    PlantDetail
};
